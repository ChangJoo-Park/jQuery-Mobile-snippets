var db;
function init(){
	document.addEventListener("deviceready", phoneReady, false);
	db = window.openDatabase("Dummy_DB", "1.0", "Just a Dummy DB", 200000); //will create database Dummy_DB or open it
}
//function will be called when device ready
function phoneReady(){
    db.transaction(setupTable, dbErrorHandler, getEntries);
}

//create table and insert some record
function setupTable(tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS SoccerPlayer (id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Club TEXT NOT NULL)');
}

//function will be called when an error occurred
function dbErrorHandler(err) {
    alert("Error processing SQL: "+err.code);
}

//function will be called when process succeed
function getEntries() {
    db.transaction(queryDB,dbErrorHandler);
}

//select all from SoccerPlayer
function queryDB(tx){
	tx.executeSql('SELECT * FROM SoccerPlayer',[],renderList,dbErrorHandler);
}

function renderList(tx,result){
	$('#SoccerPlayerList').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		$('#SoccerPlayerList').append('<li><a href="#"><h3 class="ui-li-heading">'+row['Name']+'</h3><p class="ui-li-desc">Club '+row['Club']+'</p></a></li>');
	});

	$('#SoccerPlayerList').listview("refresh");
}

$("#submitPlayer").live("click",function(){
	var name = $('#name').val();
	var club = $('#club').val();
	db.transaction(function(tx){
		// ? , ?, [?1,?2] �� 
		tx.executeSql('INSERT INTO SoccerPlayer(Name,Club) VALUES(?,?)',[name,club]);
		queryDB(tx);
	});
	$.mobile.changePage("SoccerPlayer.html");
});